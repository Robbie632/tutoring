// html element for the div that contains the carousel buttons
const carouselControls = null;
// html element for container that holds the images
const imagesContainer = dnull;
// Index used to control which image is shown
let carouselIndex = null;

let imageWidth=null;
let numImages =null;

/**
 * increments carouselIndex
 */
function increment() {
    // add code here
}
/**
 * decrements carouselIndex
 */
function decrement() {
    // add code here
}

/**
 * 
 * @param direction 'previous' | 'next'
 * shifts to an adjacent image
 */
function shift(direction) {
    // add code here

}

/**
 * Add event listener for previous and next carousel buttons
 */
carouselControls.addEventListener('click', (e) => {
    // add code here

})

/**
 * makes carousel move onto next image automatically
 */
setInterval(() => {
// add code here

}, 4000)